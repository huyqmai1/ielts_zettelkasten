Step 1:
cd ielts-zettelkasten
npm install
npm start

Step 2: run the server: 
node server.js
